import axios from "axios";
import { createUrl ,log } from "../utils/utils";

export async function addHotelInventoryapi(availableRoom,roomPrice,date) {
    const url = createUrl('/hotelInventory');
    const hotelId = sessionStorage.getItem('hotelId');
  
    if (!hotelId) {
      console.error('hotelId not found in sessionStorage');
      return null;
    }
  
    const body = {
      
      availableRoom: 0,
      roomPrice: 0,
      hotel: {
        hotelId: parseInt(hotelId), 
      },
      date: '2023-08-23',
    };
  
    try {
      const response = await axios.post(url, body);
      console.log(response.data);
      return response.data;
    } catch (ex) {
      console.error(ex);
      return null;
    }
  }
  